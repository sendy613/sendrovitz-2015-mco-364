package sendrovitz.chat;

public class ChatMain {
	
public static void main(String args[]){
	GuiServerChat a = new GuiServerChat();
	GuiClientChat b = new GuiClientChat();
	a.setVisible(true);
	b.setVisible(true);
}
}

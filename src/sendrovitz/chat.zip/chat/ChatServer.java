package sendrovitz.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.commons.io.IOUtils;

public class ChatServer {
	private JTextArea textArea;
	private String text;

	public ChatServer(JTextArea textArea) {
		this.textArea = textArea;

		try {
			
			ServerSocket serverSocket;
			serverSocket = new ServerSocket(2007);
			
			
			while (true) {
				// waits for a response
				Socket socket = serverSocket.accept();
				Thread thread = new Thread() {
					public void run() {
					
						InputStream in;
						try {
							in = socket.getInputStream();
						
							BufferedReader reader = new BufferedReader(new InputStreamReader(in));
							
							String line;
							while ((line = reader.readLine()) != null) {
								System.out.println(line);
								append(line);
							}
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

				};
				thread.start();
				}
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	

	}
	public void append(String line){
		this.textArea.append(line + "\n");
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}

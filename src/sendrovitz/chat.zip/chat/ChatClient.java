package sendrovitz.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.commons.io.IOUtils;

public class ChatClient {
	//private JTextArea textArea;
	private String text;

	public ChatClient() {

		Socket clientSocket = null;
		try {

			clientSocket = new Socket("127.0.0.1", 2007);
			OutputStream out = clientSocket.getOutputStream();
			PrintWriter writer = new PrintWriter(out);
			writer.println(getText());
			writer.flush();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			IOUtils.closeQuietly(clientSocket);
		}

	}

	public String getText() {
		return text;
	}
public void setText(String text){
	this.text =text;
}
	

}
